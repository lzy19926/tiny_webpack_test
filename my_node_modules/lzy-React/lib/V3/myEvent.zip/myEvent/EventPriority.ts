import type { Lane } from './FiberLane'
import type { DOMEventName } from './domEventsName'
import {
    NoLane,
    SyncLane,
    InputContinuousLane,
    DefaultLane,
    IdleLane,
} from './FiberLane';


//todo 维护了一个全局当前的优先级,会根据任务执行实时变化
let currentUpdatePriority: EventPriority = NoLane;

export type EventPriority = Lane; // 事件优先级
export const DiscreteEventPriority: EventPriority = SyncLane;               // 离散事件优先级(切片事件) 最高级
export const ContinuousEventPriority: EventPriority = InputContinuousLane;  // 持续事件   次高级
export const DefaultEventPriority: EventPriority = DefaultLane;             // 默认事件优先级
export const IdleEventPriority: EventPriority = IdleLane;                   // 闲置事件优先级

export function getCurrentUpdatePriority(): EventPriority {
    return currentUpdatePriority;
}

export function setCurrentUpdatePriority(newPriority: EventPriority) {
    currentUpdatePriority = newPriority;
}

// 将不同event进行分类
export function getEventPriority(domEventName: DOMEventName): EventPriority {
    switch (domEventName) {
        //! 无return时会返回2  也就是DiscreteEventPriority 
        //! 绝大部分用户事件优先级为2 最高级
        case 'cancel':
        case 'click':
        case 'close':
        case 'contextmenu':
        case 'copy':
        case 'cut':
        case 'auxclick':
        case 'dblclick':
        case 'dragend':
        case 'dragstart':
        case 'drop':
        case 'focusin':
        case 'focusout':
        case 'input':
        case 'invalid':
        case 'keydown':
        case 'keypress':
        case 'keyup':
        case 'mousedown':
        case 'mouseup':
        case 'paste':
        case 'pause':
        case 'play':
        case 'pointercancel':
        case 'pointerdown':
        case 'pointerup':
        case 'ratechange':
        case 'reset':
        case 'resize':
        case 'seeked':
        case 'submit':
        case 'touchcancel':
        case 'touchend':
        case 'touchstart':
        case 'volumechange':
        // Used by polyfills:
        // eslint-disable-next-line no-fallthrough
        case 'change':
        case 'selectionchange':
        case 'textInput':
        case 'compositionstart':
        case 'compositionend':
        case 'compositionupdate':
        // Only enableCreateEventHandleAPI:
        // eslint-disable-next-line no-fallthrough
        case 'beforeblur':
        case 'afterblur':
        // Not used by React but could be by user code:
        // eslint-disable-next-line no-fallthrough
        case 'beforeinput':
        case 'blur':
        case 'fullscreenchange':
        case 'focus':
        case 'hashchange':
        case 'popstate':
        case 'select':
        case 'selectstart':
            return DiscreteEventPriority;
        case 'drag':
        case 'dragenter':
        case 'dragexit':
        case 'dragleave':
        case 'dragover':
        case 'mousemove':
        case 'mouseout':
        case 'mouseover':
        case 'pointermove':
        case 'pointerout':
        case 'pointerover':
        case 'scroll':
        case 'toggle':
        case 'touchmove':
        case 'wheel':
        // Not used by React but could be by user code:
        // eslint-disable-next-line no-fallthrough
        case 'mouseenter':
        case 'mouseleave':
        case 'pointerenter':
        case 'pointerleave':
            return ContinuousEventPriority;
        case 'message':
            return DiscreteEventPriority;
        default:
            return DefaultEventPriority
    }
}