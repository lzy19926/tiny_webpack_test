import type { FiberNode } from '../myReactCore/GlobalFiber'

//todo 使用ES6+TS继承构造SyntheticEvent
// 在Event的基础上进行封装,添加了一些属性和方法
// 添加自定义的三个函数preventDefault,stopPropagation,isPersistent
const functionThatReturnsTrue = () => true
const functionThatReturnsFalse = () => false

export class LzySyntheticEvent {

    _reactName: string | null
    _targetFiber: FiberNode | null
    type: string
    nativeEvent: Event
    target: null | EventTarget
    currentTarget: null | EventTarget
    defaultPrevented: boolean

    constructor(
        reactName: string | null,
        reactEventType: string,
        targetFiber: FiberNode | null,
        nativeEvent: Event,
        nativeEventTarget: null | EventTarget,
    ) {
        this.addExtraPropsFromInterface(EventInterface, nativeEvent)
        this._reactName = reactName;
        this._targetFiber = targetFiber;
        this.type = reactEventType;
        this.nativeEvent = nativeEvent;
        this.target = nativeEventTarget;
        this.currentTarget = null;

        const defaultPrevented =
            nativeEvent.defaultPrevented != null
                ? nativeEvent.defaultPrevented
                : nativeEvent.returnValue === false;
        if (defaultPrevented) {
            this.isDefaultPrevented = functionThatReturnsTrue;
        } else {
            this.isDefaultPrevented = functionThatReturnsFalse;
        }
    }

    // 添加Interface中的属性给合成事件实例
    private addExtraPropsFromInterface(Interface: Object, nativeEvent: Event) {
        // 遍历Interface,给this添加原生Event属性(实现继承)
        for (const propName in Interface) {
            if (!Interface.hasOwnProperty(propName)) {
                continue;
            }
            const normalize = Interface[propName];
            if (normalize) {
                this[propName] = normalize(nativeEvent);
            } else {
                this[propName] = nativeEvent[propName];
            }
        }
    }

    isDefaultPrevented = functionThatReturnsTrue
    isPropagationStopped = functionThatReturnsFalse
    isPersistent = functionThatReturnsTrue
    preventDefault() {
        this.defaultPrevented = true;
        const event = this.nativeEvent;
        if (!event) return

        if (event.preventDefault) {
            event.preventDefault();
        }
        this.isDefaultPrevented = functionThatReturnsTrue;
    }
    stopPropagation() {
        debugger
        const event = this.nativeEvent;
        if (!event) return;

        if (event.stopPropagation) {
            event.stopPropagation()
        }
        this.isPropagationStopped = functionThatReturnsTrue;
    }
    persist() { }
}

// ---------额外需要在合成事件中挂载的属性--------------
const EventInterface = {
    // eventPhase: 0,
    // bubbles: 0,
    // cancelable: 0,
    // timeStamp: function (event: { [propName: string]: mixed }) {
    //     return event.timeStamp || Date.now();
    // },
    // defaultPrevented: 0,
    // isTrusted: 0,
};

//todo 使用ES5的方式构造SyntheticEvent(React源码)
{
    // -------------创建合成事件
    type SyntheticEventProps = {
        reactEventName: string | null,
        reactEventType: string,
        targetFiber: FiberNode | null,
        nativeEvent: Event,
        nativeEventTarget: null | EventTarget
    }
    //todo 使用ES5的方式构造SyntheticEvent(React源码)
    //! 这里直接照搬了React18中的合成事件函数, 做了一点点适配修改
    function createSyntheticEvent(Interface: any) {

        const functionThatReturnsTrue = () => true
        const functionThatReturnsFalse = () => false
        // 构造函数
        function SyntheticBaseEvent(
            reactName: string | null,
            reactEventType: string,
            targetFiber: FiberNode | null,
            nativeEvent: Event,
            nativeEventTarget: null | EventTarget,
        ) {
            this._reactName = reactName;
            this._targetFiber = targetFiber;
            this.type = reactEventType;
            this.nativeEvent = nativeEvent;
            this.target = nativeEventTarget;
            this.currentTarget = null;

            // 遍历Interface,给this添加原生Event属性(实现继承)
            for (const propName in Interface) {
                if (!Interface.hasOwnProperty(propName)) {
                    continue;
                }
                const normalize = Interface[propName];
                if (normalize) {
                    this[propName] = normalize(nativeEvent);
                } else {
                    this[propName] = nativeEvent[propName];
                }
            }

            const defaultPrevented =
                nativeEvent.defaultPrevented != null
                    ? nativeEvent.defaultPrevented
                    : nativeEvent.returnValue === false;
            if (defaultPrevented) {
                this.isDefaultPrevented = functionThatReturnsTrue;
            } else {
                this.isDefaultPrevented = functionThatReturnsFalse;
            }
            this.isPropagationStopped = functionThatReturnsFalse;
            return this;
        }

        // 给prototype上添加自定义的三个函数preventDefault,stopPropagation,isPersistent
        Object.assign(SyntheticBaseEvent.prototype, {

            preventDefault: function () {
                this.defaultPrevented = true;
                const event = this.nativeEvent;
                if (!event) return

                if (event.preventDefault) {
                    event.preventDefault();
                }
                this.isDefaultPrevented = functionThatReturnsTrue;
            },

            stopPropagation: function () {
                const event = this.nativeEvent;
                if (!event) return;

                if (event.stopPropagation) {
                    event.stopPropagation()
                }
                this.isPropagationStopped = functionThatReturnsTrue;
            },

            persist: function () { },

            isPersistent: functionThatReturnsTrue,
        });

        return SyntheticBaseEvent;
    }
}
