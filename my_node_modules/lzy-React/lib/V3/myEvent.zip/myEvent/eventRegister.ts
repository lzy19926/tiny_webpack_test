
import type { DOMEventName } from './domEventsName'
import { DOMEventNameList, nonDelegatedEvents } from './domEventsName'
import { global } from '../myReactCore/GlobalFiber'
import {
    dispatchEvent,
    dispatchDiscreteEvent,
    dispatchContinuousEvent
} from './DispatchEvent'
import {
    DiscreteEventPriority,
    ContinuousEventPriority,
    DefaultEventPriority,
    getEventPriority
} from './EventPriority'


type EventListener = (e: Event) => any

export type ContainerElement = Document | Element | DocumentFragment

export type AnyNativeEvent = Event | KeyboardEvent | MouseEvent | TouchEvent;

export const allNativeEvents: Set<DOMEventName> = new Set(); // 所有原生事件集

export const topLevelEventsToReactNames: Map<DOMEventName, string | null> = new Map(); // 顶层事件map

// reactName映射的dom事件数组(一个react事件可能对应多个原生事件)
export const reactNameDependencies: { [reactName: string]: Array<DOMEventName> } = {};


//! --------------综合方法,启动合成事件系统--------------
export function startSyntheticEventSystem(rootContainerElement: ContainerElement) {
    console.log('------合成事件系统启动------');

    global.islzySyntheticEventSystemOpen = true
    registerSimpleEvents()
    listenToAllSupportedEvents(rootContainerElement)
}
// 注册React事件  生成Map{'click'：'onClick'}
function registerSimpleEvents() {
    for (let i = 0; i < DOMEventNameList.length; i++) {
        const domEventName: DOMEventName = DOMEventNameList[i]; // click
        const capitalizedEvent = domEventName[0].toUpperCase() + domEventName.slice(1);//Click(大写)
        const reactEventName = "on" + capitalizedEvent

        topLevelEventsToReactNames.set(domEventName, reactEventName);

        registerDirectEvent(reactEventName, [domEventName]);
        registerDirectEvent(reactEventName + 'Capture', [domEventName]); // click => clickCaputre
    }

}

// 创建reactName集合,收集所有原生事件
function registerDirectEvent(reactEventName: string, domEventNames: DOMEventName[]) {

    reactNameDependencies[reactEventName] = domEventNames;

    for (let i = 0; i < domEventNames.length; i++) {
        allNativeEvents.add(domEventNames[i]);
    }
}

// 启动监听所有原生事件(非委托事件和普通事件分开处理)
function listenToAllSupportedEvents(rootContainerElement: ContainerElement) {
    allNativeEvents.forEach((domEventName) => {
        if (nonDelegatedEvents.has(domEventName)) {
            listenToNativeEvent(domEventName, false, rootContainerElement)
        } else {
            listenToNativeEvent(domEventName, true, rootContainerElement)
        }
    })
}

function listenToNativeEvent(domEventName: DOMEventName, isCapturePhaseListener: boolean, rootContainerElement: ContainerElement) {
    // console.log('监听事件', domEventName, '是否是委派事件', isCapturePhaseListener);
    // 给事件进行优先级排序,创建真正的dispatch执行对象
    const eventPriority = getEventPriority(domEventName);

    // 根据优先级,创建listener, 进行绑定
    let listenerWrapper;
    switch (eventPriority) {
        case DiscreteEventPriority:                  // 最高级
            listenerWrapper = dispatchDiscreteEvent;
            break;
        case ContinuousEventPriority:                // 次高级
            listenerWrapper = dispatchContinuousEvent;
            break;
        case DefaultEventPriority:                   // 普通级
        default:                                     // 等待级
            listenerWrapper = dispatchEvent;
            break;
    }

    // 在执行listener时,event会作为第四个参数传入,也就是nativeEvnet
    let listener = listenerWrapper.bind(null, domEventName, rootContainerElement)

    //! isCapturePhaseListener 是否是捕获阶段侦听器
    // (事件分为委派事件和非委派事件,一般的委派事件都是捕获阶段侦听器,非委派事件则不是)
    if (isCapturePhaseListener) {
        addEventCaptureListener(rootContainerElement, domEventName, listener);
    } else {
        addEventBubbleListener(rootContainerElement, domEventName, listener);
    }
}



// ! ------- 封装的原生eventListener事件-------------
function removeEventListener(
    target: EventTarget,
    eventType: string,
    listener: EventListener,
    capture: boolean,
): void {
    target.removeEventListener(eventType, listener, capture);
}

function addEventBubbleListener(
    target: EventTarget,
    eventType: string,
    listener: EventListener,
): Function {
    target.addEventListener(eventType, listener, false);
    return listener;
}

function addEventCaptureListener(
    target: EventTarget,
    eventType: string,
    listener: EventListener,
): Function {
    target.addEventListener(eventType, listener, true);
    return listener;
}


// 首先注册所有的原生事件
// registerSimpleEvents()

// 首次render/createRoot时启动监听所有原生事件
// listenToAllSupportedEvents(rootContainerElement);



// eventSystemFlags 
 // 默认传入

 export const IS_CAPTURE_PHASE = 1 << 2; 
 const isCapturePhaseListener = true // click一般是委派事件
let eventSystemFlags = 0;
if (isCapturePhaseListener) {
    eventSystemFlags |= IS_CAPTURE_PHASE;
  }

// 作用1 判断是否allowReplay
// 作用2 
// 作用3 判断 shouldProcessPolyfillPlugins
// 作用4 判断 inCapturePhase  (eventSystemFlags & IS_CAPTURE_PHASE) !== 0;



// inCapturePhase用来创建reactEventName 是否添加Capture  (默认为true)

// const captureName = reactName !== null ? reactName + 'Capture' : null;
// const reactEventName = inCapturePhase ? captureName : reactName;