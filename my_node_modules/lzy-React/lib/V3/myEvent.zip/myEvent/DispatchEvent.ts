
import type { DOMEventName } from './domEventsName'
import type { ContainerElement, AnyNativeEvent, } from './eventRegister'
import { LzySyntheticEvent } from './SyntheticEvent'
import { FiberNode } from '../myReactCore/GlobalFiber'
import { TEXT_NODE } from '../myReactCore/Constance'
import { getFiberNodeFromDom } from '../myReactCore/Constance'
import { topLevelEventsToReactNames } from './eventRegister'
import {
    DiscreteEventPriority,
    ContinuousEventPriority,
    getCurrentUpdatePriority,
    setCurrentUpdatePriority
} from './EventPriority'


type DispatchListener = {
    fiber: null | FiberNode,
    listener: Function,
    targetDom: EventTarget, // 事件触发的真实dom
};
type EventDispatcher = {
    isCapture: boolean,
    event: LzySyntheticEvent, // lzy合成事件
    listeners: Array<DispatchListener>,
};
type DispatchQueue = Array<EventDispatcher>;

//todo 触发普通事件
export function dispatchEvent(
    domEventName: DOMEventName,
    targetContainer: ContainerElement,
    nativeEvent: AnyNativeEvent,
    targetFiber: null | FiberNode,
) {
    //1/ 准备需要的参数
    const nativeEventTarget = getEventTarget(nativeEvent); //获取触发事件的dom
    const dispatchQueue: DispatchQueue = []  // dispatchQueue 提取所有监听的处理函数放到 dispatchQueue 当中

    if (!targetFiber) {
        targetFiber = getFiberNodeFromDom(nativeEventTarget) //获取触发dom对应的fiber(源码中为blockedOn)
    }

    //2. 收集沿途的冒泡事件
    extractEvents(
        dispatchQueue,
        domEventName,
        targetFiber,
        nativeEvent,
        nativeEventTarget,
        targetContainer
    )

    //3.模拟捕获阶段和冒泡阶段的执行流程，去执行所有的监听处理函数。
    processDispatchQueue(dispatchQueue); // 这里isCapture变量写死了  需修改

    // if (domEventName == 'click') {
    // console.log(domEventName, '触发dispatchEvent');
    // console.log(nativeEvent, 'nativeEvent');
    // console.log(targetFiber, 'targetFiber');
    // console.log(targetContainer, 'targetContainer');
    // console.log(nativeEventTarget, '原生事件target');
    // }
}

//todo 触发DiscreteEvent离散事件(最高优先级)  用户事件级别
// 全局维护了一个当前时间的优先级CurrentUpdatePriority, 默认为default级
// 触发click事件时, 修改当前优先级为Discrete,事件执行完毕后还原
export function dispatchDiscreteEvent(
    domEventName: DOMEventName,
    targetContainer: ContainerElement,
    nativeEvent: AnyNativeEvent,
) {
    const previousPriority = getCurrentUpdatePriority();

    try {
        setCurrentUpdatePriority(DiscreteEventPriority);
        dispatchEvent(domEventName, targetContainer, nativeEvent, null);
    } finally {
        setCurrentUpdatePriority(previousPriority); // 还原当前优先级
    }
}

//todo 触发ContinuousEvent持续事件(次高优先级)
export function dispatchContinuousEvent(
    domEventName: DOMEventName,
    targetContainer: ContainerElement,
    nativeEvent: AnyNativeEvent,
) {
    const previousPriority = getCurrentUpdatePriority();

    try {
        setCurrentUpdatePriority(ContinuousEventPriority);
        dispatchEvent(domEventName, targetContainer, nativeEvent, null);
    } finally {
        setCurrentUpdatePriority(previousPriority); // 还原当前优先级
    }
}


//! ------阶段1----收集事件-----------------
function extractEvents(
    dispatchQueue: DispatchQueue,
    domEventName: DOMEventName,
    targetFiber: null | FiberNode,
    nativeEvent: AnyNativeEvent,
    nativeEventTarget: null | EventTarget,
    targetContainer: ContainerElement
) {

    //todo 同时收集onClickCatpure和普通onClick事件
    // 冒泡层层收集listeners
    // 分为捕获情况和非捕获情况的listeners不同
    let [listeners, capturedListeners] = accumulateTowEventListeners(targetFiber, domEventName, nativeEventTarget)

    //创建合成事件对象  queue推入
    if (listeners.length > 0) {
        const reactEventName = topLevelEventsToReactNames.get(domEventName)
        const reactEventType = domEventName
        const isCapture = false

        const event = new LzySyntheticEvent(
            reactEventName,
            reactEventType,
            targetFiber,
            nativeEvent,
            nativeEventTarget,
        )
        dispatchQueue.push({ event, listeners, isCapture });
    }
    //Capture事件推入queue
    if (capturedListeners.length > 0) {
        const reactEventName = topLevelEventsToReactNames.get(domEventName) + 'Capture'
        const reactEventType = domEventName
        const isCapture = true
        const listeners = capturedListeners

        const event = new LzySyntheticEvent(
            reactEventName,
            reactEventType,
            targetFiber,
            nativeEvent,
            nativeEventTarget,
        )

        dispatchQueue.push({ event, listeners, isCapture });
    }
}

// 仅收集onClick事件
function accumulateSingleEventListeners() {

}
// 同时收集onClick,onClickCapture事件
// 从当前fiber出发,根据事件名"onClick",一直向上收集props(sourcePool)中所有事件
function accumulateTowEventListeners(
    targetFiber: FiberNode,
    domEventName: DOMEventName,
    nativeEventTarget: null | EventTarget
) {
    const listeners: Array<DispatchListener> = []
    const capturedListeners: Array<DispatchListener> = []

    const reactName = topLevelEventsToReactNames.get(domEventName);
    const reactNameCapture = reactName + 'Capture'

    if (reactName === undefined) return [listeners, capturedListeners];

    // 冒泡收集两种listener
    let currentFiber = targetFiber
    while (currentFiber) {
        let props = currentFiber._element?.props
        let nativeListener = props?.[reactName]
        let nativeListenerCapture = props?.[reactNameCapture]

        nativeListener && listeners.push(
            newDispatchListener(
                currentFiber,
                nativeListener,
                nativeEventTarget
            ))
        nativeListenerCapture && capturedListeners.push(
            newDispatchListener(
                currentFiber,
                nativeListenerCapture,
                nativeEventTarget
            ))
        currentFiber = currentFiber._parent
    }

    return [listeners, capturedListeners]
}

// 创建一个newDispatchListener实例
function newDispatchListener(
    fiber: null | FiberNode,
    listener: Function,
    targetDom: EventTarget,
): DispatchListener {
    return {
        fiber,
        listener,
        targetDom
    }
}

// 从原生event对象中获取target
function getEventTarget(nativeEvent: any): EventTarget {
    // 兼容IE9
    let target = nativeEvent.target || nativeEvent.srcElement || window;

    if (target.correspondingUseElement) {
        target = target.correspondingUseElement;
    }
    // 兼容Safari
    return target.nodeType === TEXT_NODE ? target.parentNode : target;
}



//! ------阶段2--模拟捕获阶段和冒泡阶段的执行流程，去执行所有的监听处理函数。------------
function processDispatchQueue(dispatchQueue: DispatchQueue) {
    // console.log('模拟执行流程', dispatchQueue);
    for (let i = 0; i < dispatchQueue.length; i++) {
        let isCapture = dispatchQueue[i]?.isCapture

        isCapture
            ? executeDispatch_Capture(dispatchQueue[i])
            : executeDispatch_Bubble(dispatchQueue[i])
    }
}

// 模拟捕获阶段的事件执行(从父->子)
function executeDispatch_Bubble(eventDispatcher: EventDispatcher) {
    const { event, listeners } = eventDispatcher

    let previousFiber; // 记录上一个listener记录的fiber(如果不符合则退出执行)(应该是react内部为了处理fiber获取错误上的锁)
    for (let i = listeners.length - 1; i >= 0; i--) {
        const { fiber, listener, targetDom } = listeners[i];
        if (fiber !== previousFiber && event.isPropagationStopped()) return

        executeDispatch(event, listener, targetDom);
        previousFiber = fiber;
    }
}

// 模拟冒泡阶段的事件执行(从子->父)
function executeDispatch_Capture(eventDispatcher: EventDispatcher) {
    const { event, listeners } = eventDispatcher

    let previousFiber; // 记录上一个listener记录的fiber(如果不符合则退出执行)(应该是react内部为了处理fiber获取错误上的锁)
    for (let i = 0; i < listeners.length; i++) {
        const { fiber, listener, targetDom } = listeners[i];
        if (fiber !== previousFiber && event.isPropagationStopped()) return

        executeDispatch(event, listener, targetDom);
        previousFiber = fiber;
    }
}

// 执行listener
function executeDispatch(
    event: LzySyntheticEvent,
    listener: Function,
    currentTarget: EventTarget,
): void {
    event.currentTarget = currentTarget;

    try {
        listener.call(null, event)
    } catch (error) {
        throw new Error(error)
    }

    event.currentTarget = null;
}