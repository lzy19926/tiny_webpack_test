
export const DOMEventNameList: DOMEventName[] = [
    'abort',
    'afterblur',
    'beforeblur',
    'beforeinput',
    'blur',
    'canplay',
    'canplaythrough',
    'cancel',
    'change',
    'click',
    'close',
    'compositionend',
    'compositionstart',
    'compositionupdate',
    'contextmenu',
    'copy',
    'cut',
    'dblclick',
    'auxclick',
    'drag',
    'dragend',
    'dragenter',
    'dragexit',
    'dragleave',
    'dragover',
    'dragstart',
    'drop',
    'durationchange',
    'emptied',
    'encrypted',
    'ended',
    'error',
    'focus',
    'focusin',
    'focusout',
    'fullscreenchange',
    'gotpointercapture',
    'hashchange',
    'input',
    'invalid',
    'keydown',
    'keypress',
    'keyup',
    'load',
    'loadstart',
    'loadeddata',
    'loadedmetadata',
    'lostpointercapture',
    'message',
    'mousedown',
    'mouseenter',
    'mouseleave',
    'mousemove',
    'mouseout',
    'mouseover',
    'mouseup',
    'paste',
    'pause',
    'play',
    'playing',
    'pointercancel',
    'pointerdown',
    'pointerenter',
    'pointerleave',
    'pointermove',
    'pointerout',
    'pointerover',
    'pointerup',
    'popstate',
    'progress',
    'ratechange',
    'reset',
    'resize',
    'scroll',
    'seeked',
    'seeking',
    'select',
    'selectstart',
    'selectionchange',
    'stalled',
    'submit',
    'suspend',
    'textInput',
    'timeupdate',
    'toggle',
    'touchcancel',
    'touchend',
    'touchmove',
    'touchstart',
    // 'transitionend',
    'volumechange',
    'waiting',
    'wheel'
]
//todo 媒体事件
export const mediaEventTypes: Array<DOMEventName> = [
    'abort',
    'canplay',
    'canplaythrough',
    'durationchange',
    'emptied',
    'encrypted',
    'ended',
    'error',
    'loadeddata',
    'loadedmetadata',
    'loadstart',
    'pause',
    'play',
    'playing',
    'progress',
    'ratechange',
    'resize',
    'seeked',
    'seeking',
    'stalled',
    'suspend',
    'timeupdate',
    'volumechange',
    'waiting',
];
//todo 非委托事件(与普通委托事件不同,需要特殊处理)
export const nonDelegatedEvents: Set<DOMEventName> = new Set([
    'cancel',
    'close',
    'invalid',
    'load',
    'scroll',
    'toggle',
    ...mediaEventTypes,
]);

export type DOMEventName =
    | 'abort'
    | 'afterblur' // Not a real event. This is used by event experiments.
    // These are vendor-prefixed so you should use the exported constants instead:
    // 'animationiteration' |
    // 'animationend |
    // 'animationstart' |
    | 'beforeblur' // Not a real event. This is used by event experiments.
    | 'beforeinput'
    | 'blur'
    | 'canplay'
    | 'canplaythrough'
    | 'cancel'
    | 'change'
    | 'click'
    | 'close'
    | 'compositionend'
    | 'compositionstart'
    | 'compositionupdate'
    | 'contextmenu'
    | 'copy'
    | 'cut'
    | 'dblclick'
    | 'auxclick'
    | 'drag'
    | 'dragend'
    | 'dragenter'
    | 'dragexit'
    | 'dragleave'
    | 'dragover'
    | 'dragstart'
    | 'drop'
    | 'durationchange'
    | 'emptied'
    | 'encrypted'
    | 'ended'
    | 'error'
    | 'focus'
    | 'focusin'
    | 'focusout'
    | 'fullscreenchange'
    | 'gotpointercapture'
    | 'hashchange'
    | 'input'
    | 'invalid'
    | 'keydown'
    | 'keypress'
    | 'keyup'
    | 'load'
    | 'loadstart'
    | 'loadeddata'
    | 'loadedmetadata'
    | 'lostpointercapture'
    | 'message'
    | 'mousedown'
    | 'mouseenter'
    | 'mouseleave'
    | 'mousemove'
    | 'mouseout'
    | 'mouseover'
    | 'mouseup'
    | 'paste'
    | 'pause'
    | 'play'
    | 'playing'
    | 'pointercancel'
    | 'pointerdown'
    | 'pointerenter'
    | 'pointerleave'
    | 'pointermove'
    | 'pointerout'
    | 'pointerover'
    | 'pointerup'
    | 'popstate'
    | 'progress'
    | 'ratechange'
    | 'reset'
    | 'resize'
    | 'scroll'
    | 'seeked'
    | 'seeking'
    | 'select'
    | 'selectstart'
    | 'selectionchange'
    | 'stalled'
    | 'submit'
    | 'suspend'
    | 'textInput' // Intentionally camelCase. Non-standard.
    | 'timeupdate'
    | 'toggle'
    | 'touchcancel'
    | 'touchend'
    | 'touchmove'
    | 'touchstart'
    // These are vendor-prefixed so you should use the exported constants instead:
    // 'transitionend' |
    | 'volumechange'
    | 'waiting'
    | 'wheel';